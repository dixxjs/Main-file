package com.example.demo.note;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface NoteImageRepository extends JpaRepository<NoteImage, Long> {

    // 날짜 목록만 뽑기
    @Query("SELECT DISTINCT n.date FROM NoteImage n ORDER BY n.date DESC")
    List<String> findAllDates();

    // 특정 날짜 이미지들
    List<NoteImage> findByDateOrderByIdDesc(String date);

    // 🔹 카테고리 필터 추가 가능
    List<NoteImage> findByCategoryId(Long categoryId);
}
