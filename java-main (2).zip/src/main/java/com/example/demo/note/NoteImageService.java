package com.example.demo.note;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.*;
import java.util.UUID;

@Service
public class NoteImageService {

    private final NoteImageRepository noteImageRepository;

    public NoteImageService(NoteImageRepository noteImageRepository) {
        this.noteImageRepository = noteImageRepository;
    }
    
    public List<String> getDates() {
       return noteImageRepository.findAllDates();
    }

    public String saveImage(String date, MultipartFile file, Long categoryId) throws Exception {

        Path folder = Paths.get("uploads/note-images/" + date).toAbsolutePath();
        Files.createDirectories(folder);

        String original = file.getOriginalFilename();
        String ext = (original != null && original.contains(".")) 
                     ? original.substring(original.lastIndexOf(".")) 
                     : ".png";

        String filename = UUID.randomUUID().toString() + ext;
        Path target = folder.resolve(filename);

        Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);

        String url = "/note-images/files/" + date + "/" + filename;

        NoteImage img = new NoteImage();
        img.setDate(date);
        img.setImgUrl(url);
        img.setCategoryId(categoryId);

        noteImageRepository.save(img);

        return url;
    }
}
