package com.example.demo.note;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class NoteImageController {

    private final NoteImageRepository noteImageRepository;
    private final NoteImageService noteImageService;

    public NoteImageController(NoteImageRepository noteImageRepository,
                               NoteImageService noteImageService) {
        this.noteImageRepository = noteImageRepository;
        this.noteImageService = noteImageService;
    }
    
    // 날짜 목록
@GetMapping("/note-images/dates")
public List<String> getImageDates() {
    return noteImageService.getDates();
}

    // 특정 날짜 이미지 목록
    @GetMapping("/note-images")
    public List<String> getImagesByDate(@RequestParam String date) {
        return noteImageRepository.findByDateOrderByIdDesc(date)
                .stream()
                .map(NoteImage::getImgUrl)
                .collect(Collectors.toList());
    }

    // 이미지 업로드 저장
    @PostMapping("/note-images/upload")
    public ResponseEntity<String> upload(
            @RequestParam("date") String date,
            @RequestParam("categoryId") Long categoryId,
            @RequestParam("file") MultipartFile file) {

        try {
            String url = noteImageService.saveImage(date, file, categoryId);
            return ResponseEntity.ok(url);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("error");
        }
    }
}
