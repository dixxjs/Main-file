package com.example.demo.domain;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;

@Repository 
public interface NoteRepository extends JpaRepository<Note, Long> {
    List<Note> findByNoteDate(Date noteDate);

    // 학생별 조회 (필요한 경우 남김)
    List<Note> findByStudentId(Long studentId);

    // 저장된 모든 날짜 목록 조회
    @Query("SELECT DISTINCT n.noteDate FROM Note n ORDER BY n.noteDate DESC")
    List<Date> findDistinctDates();
    // ✔ 추가할 메서드
    List<Note> findByStudentIdAndNoteDate(Long studentId, Date noteDate);
    // NoteRepository.java
    @Query("SELECT DISTINCT n.noteDate FROM Note n WHERE n.studentId = :studentId ORDER BY n.noteDate DESC")
    List<Date> findDistinctNoteDateByStudentId(@Param("studentId") Long studentId);
}
