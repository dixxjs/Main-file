package com.example.demo.service;

import com.example.demo.domain.Note;
import com.example.demo.domain.NoteRepository;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;

@Service
public class NoteService {

    private final NoteRepository noteRepository;

    public NoteService(NoteRepository noteRepository) {
        this.noteRepository = noteRepository;
    }
    // ✔ 추가할 메서드
    public List<Note> getNotesByStudentAndDate(Long studentId, Date date) {
        return noteRepository.findByStudentIdAndNoteDate(studentId, date);
    }

    
    // 필기 저장
    public Note save(Long studentId, String title, String content, Date noteDate, String type) {
        Note note = new Note();
        note.setStudentId(studentId);
        note.setTitle(title);
        note.setContent(content);
        note.setNoteDate(noteDate);
        note.setType(type);
        return noteRepository.save(note);
    }
    // NoteService.java
    public List<Date> getDistinctNoteDatesByStudent(Long studentId) {
        return noteRepository.findDistinctNoteDateByStudentId(studentId);
    }

    // 학생별 모든 필기 조회
    public List<Note> getNotesByStudent(Long studentId) {
        return noteRepository.findByStudentId(studentId);
    }

}
