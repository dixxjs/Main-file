package com.example.demo.Web;

import com.example.demo.domain.Note;
import com.example.demo.service.NoteService;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/note")
public class NoteController {

    private final NoteService noteService;

    public NoteController(NoteService noteService) {
        this.noteService = noteService;
    }

    @PostMapping("/save")
    public String save(@RequestBody Map<String, String> req) {
        Long studentId = Long.parseLong(req.get("studentId"));
        String title = req.get("title");
        String content = req.get("content");
        String type = req.get("type");
        Date noteDate = Date.valueOf(req.get("noteDate"));

        noteService.save(studentId, title, content, noteDate, type);
        return "OK";
    }
    
    @GetMapping("/dates")
    public List<String> getNoteDates(@RequestParam Long studentId) {
        return noteService.getDistinctNoteDatesByStudent(studentId)
            .stream()
            .map(Date::toString)
            .toList();
}

    @GetMapping("/list/byDate")
    public List<Note> getNotesByDate(@RequestParam String date) {
        return noteService.getNotesByDate(Date.valueOf(date));
    }

    @GetMapping("/list/byStudent")
    public List<Note> getNotesByStudent(@RequestParam Long studentId) {
        return noteService.getNotesByStudent(studentId);
    }
}
