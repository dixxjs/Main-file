package com.example.demo.Web;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class BrainController {

    @GetMapping("/brain")
    public String brainPage(HttpSession session) {
        if (session.getAttribute("student") == null) {
            return "redirect:/login";
        }
        return "brain"; // templates/brain.html
    }
}
